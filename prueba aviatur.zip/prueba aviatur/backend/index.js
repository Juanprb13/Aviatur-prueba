import express from "express";
import fs from "fs";

const readFile = fs.readFileSync("../recursos/data/data.json")
const app = express();

//get values JSON data
const info  = JSON.parse(readFile) 
//Endpoints
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   next();
  });
app.get("/hotels",(req,res)=>{

    const {name,stars} = req.query;
    let  queryData = info
    if(name){
        queryData = info.filter((val)=> val.name == name)
    }
    if(stars){
        const mapStars =  stars.split(",")
        const filtro = [];
       queryData.filter(element=>{   
        mapStars.filter(buscador => {
                if(element.stars == buscador) filtro.push(element)
            })
       })
       queryData = filtro
    }   
    res.json(queryData )
})


// listen port server
app.listen(3000,()=>console.log("Server running !!!!!"))