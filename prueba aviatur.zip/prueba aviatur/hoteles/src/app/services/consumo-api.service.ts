import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConsumoApiService {

  apiURL:string = "http://localhost:3000/hotels"

  constructor(
    private HttpClient: HttpClient
  ) { }

  public getHotels(name?:string,stars?:string){

    let urlFilter = `${this.apiURL}`
    
    if(name) {
      urlFilter =urlFilter+`?name=${name}`
      localStorage.setItem("filter","true")
    }
    if(stars) urlFilter =urlFilter+`?stars=${stars}`
    
    return this.HttpClient.get<Object[]>(urlFilter).subscribe(res => (localStorage.setItem("Hoteles",JSON.stringify(res))))

  }

}
