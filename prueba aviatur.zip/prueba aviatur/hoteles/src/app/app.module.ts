import { NgModule, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ConsumoApiService } from './services/consumo-api.service';
import { FiltroComponentComponent } from './components/filtro-component/filtro-component.component';
import { HotelesComponentComponent } from './components/hoteles-component/hoteles-component.component';
@NgModule({
  declarations: [
    AppComponent,
    FiltroComponentComponent,
    HotelesComponentComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule  implements OnInit{ 

  constructor(private hotelService:ConsumoApiService){

  }
  ngOnInit(){ 
    console.log("asdasd");
    
    
  }

}
