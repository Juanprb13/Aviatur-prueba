import { Hoteles } from './hoteles';

describe('Hoteles', () => {
  it('should create an instance', () => {
    expect(new Hoteles()).toBeTruthy();
  });
});
