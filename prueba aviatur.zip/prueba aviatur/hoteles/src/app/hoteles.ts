export class Hoteles {

}
