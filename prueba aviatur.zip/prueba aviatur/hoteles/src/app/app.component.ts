import { Component, OnInit } from '@angular/core';
import { ConsumoApiService } from './services/consumo-api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'hoteles';

  constructor(private hotelService:ConsumoApiService ){}

 
}


