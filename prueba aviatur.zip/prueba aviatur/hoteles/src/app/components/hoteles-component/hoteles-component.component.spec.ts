import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelesComponentComponent } from './hoteles-component.component';

describe('HotelesComponentComponent', () => {
  let component: HotelesComponentComponent;
  let fixture: ComponentFixture<HotelesComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotelesComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelesComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
