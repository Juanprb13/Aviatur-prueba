import { Component, OnInit } from '@angular/core';
import { ConsumoApiService } from 'src/app/services/consumo-api.service';

@Component({
  selector: 'app-hoteles-component',
  templateUrl: './hoteles-component.component.html',
  styleUrls: ['./hoteles-component.component.css']
})
export class HotelesComponentComponent implements OnInit {

  Arr = Array; //Array type captured in a variable
  num:number = 20;

  hoteles:any;
  constructor(private hotelService:ConsumoApiService){
  }

  ngOnInit(): void {
    const data = localStorage.getItem('Hoteles') 
    this.hoteles =JSON.parse(data?data:"")
  }

}
