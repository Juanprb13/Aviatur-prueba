import { Component, Input, OnInit } from '@angular/core';
import { ConsumoApiService } from 'src/app/services/consumo-api.service';

@Component({
  selector: 'app-filtro-component',
  templateUrl: './filtro-component.component.html',
  styleUrls: ['./filtro-component.component.css']
})
export class FiltroComponentComponent implements OnInit {

  Arr = Array; //Array type captured in a variable
  constructor(private hotelService: ConsumoApiService) { }
  flagFilter:any 
  star : string="";
  name : string=""

  ngOnInit(): void {
    this.flagFilter = localStorage.getItem("filter")

  }

  buscarHotel(event:any){
    
     this.name = event.target.value

    this.hotelService.getHotels(this.name,this.star)
    window.location.reload()

  }

  buscarHotelByStar(event:any){
    
    
    this.star = event.target.value

    localStorage.setItem("filter","true")
   this.hotelService.getHotels(this.name,this.star)
   window.location.reload()

 }
  

  setFilter(){
    
    this.hotelService.getHotels("")
    localStorage.setItem("filter","false")
    window.location.reload()
  }

}
